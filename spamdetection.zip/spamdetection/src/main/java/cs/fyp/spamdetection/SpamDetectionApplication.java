package cs.fyp.spamdetection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpamDetectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpamDetectionApplication.class, args);
	}

}
