package cs.fyp.spamdetection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpamDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
